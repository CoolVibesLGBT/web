CoolVibes Brandkit — dott-v3

Transparent PNG wordmark, 9 PNG icon sizes (16, 32, 64, 128, 180, 192, 256, 512, 1024), 1200x630 JPG social cover.

Palette (design reference): #56C8CE #8774E1 #082C72 #3390EC #FF6055 #FF9500 #FFD45C #ADD64B

Keep clear space around the logo. Preserve proportions, colors and lettering. Use a simple background with sufficient contrast.
Raster assets; editable vector files are not included.
https://coolvibes.lgbt/brandkit
